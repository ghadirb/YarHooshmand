#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_project.py
نسخهٔ سبک‌شدهٔ پروژه‌ی "یار هوشمند" را می‌سازد.
فایل‌ها و پوشه‌ها را مطابق ساختار Android Studio می‌سازد.
"""

import os
from pathlib import Path
import textwrap

ROOT = Path.cwd() / "YarHooshmand"
APP = ROOT / "app"
SRC_MAIN = APP / "src" / "main"
JAVA_PKG = SRC_MAIN / "java" / "com" / "example" / "yarhooshmand"
RES = SRC_MAIN / "res"
LAYOUT = RES / "layout"
VALUES = RES / "values"
GRADLE_WRAPPER = ROOT / "gradle" / "wrapper"

def write(path: Path, content: str, mode='w', binary=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if binary:
        path.write_bytes(content)
    else:
        path.write_text(content, encoding='utf-8')
    print("Wrote:", path)

# 1) settings.gradle
write(ROOT / "settings.gradle", 'rootProject.name = "YarHooshmand"\ninclude ":app"\n')

# 2) root build.gradle
root_build = textwrap.dedent("""\
    buildscript {
        repositories {
            google()
            mavenCentral()
        }
        dependencies {
            classpath "com.android.tools.build:gradle:7.4.2"
        }
    }
    allprojects {
        repositories {
            google()
            mavenCentral()
        }
    }
""")
write(ROOT / "build.gradle", root_build)

# 3) gradle wrapper properties (minimal)
gradle_wrapper_props = textwrap.dedent("""\
    distributionBase=GRADLE_USER_HOME
    distributionPath=wrapper/dists
    zipStoreBase=GRADLE_USER_HOME
    zipStorePath=wrapper/dists
    distributionUrl=https\\://services.gradle.org/distributions/gradle-7.5-bin.zip
""")
write(GRADLE_WRAPPER / "gradle-wrapper.properties", gradle_wrapper_props)

# 4) small placeholder gradle wrapper jar/text (these are placeholders; real wrapper jar will be downloaded by gradle)
write(GRADLE_WRAPPER / "gradle-wrapper.jar", "// placeholder for gradle-wrapper.jar\n")
# also add example gradlew and gradlew.bat
write(ROOT / "gradlew", "#!/bin/sh\n./gradlew \"$@\"\n")
write(ROOT / "gradlew.bat", "@echo off\r\nREM call gradlew.bat %*\r\ngradlew %*\r\n")

# 5) app/build.gradle
app_build = textwrap.dedent("""\
    apply plugin: 'com.android.application'
    apply plugin: 'kotlin-android'

    android {
        compileSdkVersion 33
        defaultConfig {
            applicationId "com.example.yarhooshmand"
            minSdkVersion 28
            targetSdkVersion 33
            versionCode 1
            versionName "1.0"
        }
        buildTypes {
            release {
                minifyEnabled false
            }
        }
        buildFeatures {
            viewBinding true
        }
    }

    dependencies {
        implementation "org.jetbrains.kotlin:kotlin-stdlib:1.8.22"
        implementation 'androidx.core:core-ktx:1.9.0'
        implementation 'androidx.appcompat:appcompat:1.6.1'
        implementation 'com.google.android.material:material:1.8.0'
        implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
        implementation 'com.squareup.okhttp3:okhttp:4.11.0'
    }
""")
write(APP / "build.gradle", app_build)

# 6) AndroidManifest.xml
manifest = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <manifest package="com.example.yarhooshmand" xmlns:android="http://schemas.android.com/apk/res/android">
        <uses-permission android:name="android.permission.INTERNET" />
        <uses-permission android:name="android.permission.RECORD_AUDIO" />
        <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
        <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

        <application android:label="یار هوشمند" android:allowBackup="true">
            <activity android:name=".MainActivity">
                <intent-filter>
                    <action android:name="android.intent.action.MAIN"/>
                    <category android:name="android.intent.category.LAUNCHER"/>
                </intent-filter>
            </activity>
            <activity android:name=".SimpleReminderActivity"/>
            <activity android:name=".SmartActivity"/>
            <receiver android:name=".ReminderReceiver" android:exported="true"/>
            <receiver android:name=".BootReceiver" android:exported="true">
                <intent-filter>
                    <action android:name="android.intent.action.BOOT_COMPLETED"/>
                </intent-filter>
            </receiver>
        </application>
    </manifest>
""")
write(SRC_MAIN / "AndroidManifest.xml", manifest)

# 7) Kotlin sources
main_activity = textwrap.dedent("""\
    package com.example.yarhooshmand

    import android.content.Intent
    import android.os.Bundle
    import androidx.appcompat.app.AppCompatActivity
    import com.example.yarhooshmand.databinding.ActivityMainBinding

    class MainActivity : AppCompatActivity() {
        private lateinit var b: ActivityMainBinding
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            b = ActivityMainBinding.inflate(layoutInflater)
            setContentView(b.root)

            b.simpleBtn.setOnClickListener {
                startActivity(Intent(this, SimpleReminderActivity::class.java))
            }
            b.smartBtn.setOnClickListener {
                startActivity(Intent(this, SmartActivity::class.java))
            }
        }
    }
""")
write(JAVA_PKG / "MainActivity.kt", main_activity)

simple_activity = textwrap.dedent("""\
    package com.example.yarhooshmand

    import android.app.AlarmManager
    import android.app.PendingIntent
    import android.content.Context
    import android.content.Intent
    import android.os.Build
    import android.os.Bundle
    import android.widget.Toast
    import androidx.appcompat.app.AppCompatActivity
    import com.example.yarhooshmand.databinding.ActivitySimpleBinding

    class SimpleReminderActivity : AppCompatActivity() {
        private lateinit var b: ActivitySimpleBinding
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            b = ActivitySimpleBinding.inflate(layoutInflater)
            setContentView(b.root)

            b.btnSet.setOnClickListener {
                val msg = b.etMessage.text.toString().trim()
                if (msg.isEmpty()) { Toast.makeText(this,"متن وارد کنید",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                val trigger = System.currentTimeMillis() + 60_000L // demo: 1 دقیقه بعد
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", msg)
                val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                else PendingIntent.FLAG_UPDATE_CURRENT
                val p = PendingIntent.getBroadcast(this, msg.hashCode(), intent, flags)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, p)
                else am.setExact(AlarmManager.RTC_WAKEUP, trigger, p)
                Toast.makeText(this,"یادآور تنظیم شد", Toast.LENGTH_SHORT).show()
            }
        }
    }
""")
write(JAVA_PKG / "SimpleReminderActivity.kt", simple_activity)

reminder_receiver = textwrap.dedent("""\
    package com.example.yarhooshmand

    import android.app.NotificationChannel
    import android.app.NotificationManager
    import android.content.BroadcastReceiver
    import android.content.Context
    import android.content.Intent
    import androidx.core.app.NotificationCompat

    class ReminderReceiver: BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val message = intent.getStringExtra("message") ?: "یادآوری شما"
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "yar_channel"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                nm.createNotificationChannel(NotificationChannel(channelId,"یادآورها", NotificationManager.IMPORTANCE_HIGH))
            }
            val n = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("یادآور")
                .setContentText(message)
                .setAutoCancel(true).build()
            nm.notify(message.hashCode(), n)
        }
    }
""")
write(JAVA_PKG / "ReminderReceiver.kt", reminder_receiver)

boot_receiver = textwrap.dedent("""\
    package com.example.yarhooshmand

    import android.app.AlarmManager
    import android.app.PendingIntent
    import android.content.BroadcastReceiver
    import android.content.Context
    import android.content.Intent
    import android.os.Build

    class BootReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
                val prefs = context.getSharedPreferences("yar_prefs", Context.MODE_PRIVATE)
                val msg = prefs.getString("last_message", null)
                val time = prefs.getLong("last_time", -1L)
                if (msg != null && time > System.currentTimeMillis()) {
                    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val i = Intent(context, ReminderReceiver::class.java).putExtra("message", msg)
                    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    else PendingIntent.FLAG_UPDATE_CURRENT
                    val p = PendingIntent.getBroadcast(context, msg.hashCode(), i, flags)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, p)
                    } else {
                        am.setExact(AlarmManager.RTC_WAKEUP, time, p)
                    }
                }
            }
        }
    }
""")
write(JAVA_PKG / "BootReceiver.kt", boot_receiver)

smart_activity = textwrap.dedent("""\
    package com.example.yarhooshmand

    import android.Manifest
    import android.content.pm.PackageManager
    import android.os.Build
    import android.os.Bundle
    import android.speech.RecognizerIntent
    import android.speech.SpeechRecognizer
    import android.speech.tts.TextToSpeech
    import android.view.View
    import android.widget.Toast
    import androidx.activity.result.contract.ActivityResultContracts
    import androidx.appcompat.app.AppCompatActivity
    import androidx.core.content.ContextCompat
    import com.example.yarhooshmand.databinding.ActivitySmartBinding
    import kotlinx.coroutines.CoroutineScope
    import kotlinx.coroutines.Dispatchers
    import kotlinx.coroutines.launch
    import kotlinx.coroutines.withContext
    import okhttp3.MediaType.Companion.toMediaTypeOrNull
    import okhttp3.OkHttpClient
    import okhttp3.Request
    import okhttp3.RequestBody
    import org.json.JSONObject
    import java.util.*

    class SmartActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
        private lateinit var b: ActivitySmartBinding
        private val client = OkHttpClient()
        private val prefsName = "yar_prefs"
        private var key: String? = null
        private var endpoint: String? = null
        private var tts: TextToSpeech? = null
        private val driveDefault = "https://drive.google.com/uc?export=download&id=17iwkjyGcxJeDgwQWEcsOdfbOxOah_0u0"

        private val recordPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) Toast.makeText(this, "اجازهٔ دسترسی به میکروفون لازم است", Toast.LENGTH_SHORT).show()
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            b = ActivitySmartBinding.inflate(layoutInflater)
            setContentView(b.root)
            tts = TextToSpeech(this, this)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
            key = prefs.getString("selected_key", null)
            endpoint = prefs.getString("selected_endpoint", null)
            b.tvStatus.text = if (key != null) "کلید: موجود" else "کلید: ندارد"
            b.tvFree.text = "استفادهٔ رایگان: " + prefs.getInt("free_uses_left", 5).toString()

            b.btnUpdateKeys.setOnClickListener {
                b.progress.visibility = View.VISIBLE
                CoroutineScope(Dispatchers.IO).launch {
                    val link = prefs.getString("drive_link", driveDefault) ?: driveDefault
                    downloadAndSelectKey(link)
                    withContext(Dispatchers.Main) {
                        b.progress.visibility = View.GONE
                        b.tvStatus.text = if (key != null) "کلید: موجود" else "کلید: ندارد"
                    }
                }
            }

            b.btnSend.setOnClickListener {
                val text = b.etInput.text.toString().trim()
                if (text.isEmpty()) return@setOnClickListener
                if (prefs.getInt("free_uses_left", 5) <= 0) {
                    Toast.makeText(this, "بخش هوشمند قفل است — لطفا خرید کنید.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit().putInt("free_uses_left", prefs.getInt("free_uses_left", 5) - 1).apply()
                b.tvFree.text = "استفادهٔ رایگان: " + prefs.getInt("free_uses_left", 5).toString()
                b.progress.visibility = View.VISIBLE
                CoroutineScope(Dispatchers.IO).launch {
                    val reply = callModel(text)
                    withContext(Dispatchers.Main) {
                        b.progress.visibility = View.GONE
                        if (reply != null) {
                            b.tvChat.append("شما: " + text + "\\nیار: " + reply + "\\n\\n")
                            tts?.speak(reply, TextToSpeech.QUEUE_ADD, null, "resp")
                        } else {
                            b.tvChat.append("خطا در تماس با مدل\\n")
                        }
                    }
                }
            }

            b.btnMic.setOnClickListener {
                startVoiceInput()
            }
        }

        private fun startVoiceInput() {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Toast.makeText(this, "تشخیص گفتار در دستگاه فعال نیست", Toast.LENGTH_SHORT).show()
                return
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "صحبت کنید...")
            startActivityForResult(i, 901)
        }

        override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (requestCode == 901 && resultCode == RESULT_OK) {
                val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                if (!matches.isNullOrEmpty()) {
                    b.etInput.setText(matches[0])
                }
            }
        }

        private fun downloadAndSelectKey(url: String) {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return
                    val body = resp.body?.string() ?: return
                    val lines = body.split(Regex("\\\\r?\\\\n")).map { it.trim() }.filter { it.isNotEmpty() }
                    for (l in lines) {
                        val service = if (l.contains(":")) l.substringBefore(":") else "openai"
                        val rawKey = if (l.contains(":")) l.substringAfter(":") else l
                        endpoint = when (service.lowercase(Locale.getDefault())) {
                            "openrouter" -> "https://api.openrouter.ai/v1/chat/completions"
                            else -> "https://api.openai.com/v1/chat/completions"
                        }
                        key = rawKey
                        getSharedPreferences(prefsName, MODE_PRIVATE).edit().putString("selected_key", key).putString("selected_endpoint", endpoint).apply()
                        return
                    }
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        private fun callModel(prompt: String): String? {
            try {
                val json = JSONObject()
                val messages = org.json.JSONArray()
                val m = JSONObject()
                m.put("role", "user")
                m.put("content", prompt)
                messages.put(m)
                json.put("model", "gpt-3.5-turbo")
                json.put("messages", messages)
                val body = RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json.toString())
                val req = Request.Builder().url(endpoint ?: return null).addHeader("Authorization", "Bearer " + (key ?: "")).post(body).build()
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return null
                    val s = r.body?.string() ?: return null
                    val jo = JSONObject(s)
                    val choices = jo.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val c0 = choices.getJSONObject(0)
                        val msg = c0.optJSONObject("message")?.optString("content") ?: c0.optString("text", null)
                        return msg
                    }
                    return jo.optString("answer", null)
                }
            } catch (e: Exception) { e.printStackTrace(); return null }
        }

        override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("fa","IR") }
        override fun onDestroy() { super.onDestroy(); tts?.shutdown() }
    }
""")
write(JAVA_PKG / "SmartActivity.kt", smart_activity)

# 8) layouts and values
activity_main_xml = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent" android:layout_height="match_parent"
        android:orientation="vertical" android:padding="24dp" android:gravity="center">

        <Button android:id="@+id/simpleBtn" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="بخش ساده"/>
        <Button android:id="@+id/smartBtn" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="بخش هوشمند" android:layout_marginTop="16dp"/>
    </LinearLayout>
""")
write(LAYOUT / "activity_main.xml", activity_main_xml)

activity_simple_xml = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent" android:layout_height="match_parent"
        android:orientation="vertical" android:padding="16dp">

        <EditText android:id="@+id/etMessage" android:layout_width="match_parent" android:layout_height="wrap_content" android:hint="متن یادآور"/>
        <Button android:id="@+id/btnSet" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="تنظیم یادآور" android:layout_marginTop="12dp"/>
    </LinearLayout>
""")
write(LAYOUT / "activity_simple.xml", activity_simple_xml)

activity_smart_xml = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent" android:layout_height="match_parent"
        android:orientation="vertical" android:padding="8dp">

        <EditText android:id="@+id/etDriveLink" android:layout_width="match_parent" android:layout_height="wrap_content" android:hint="لینک Google Drive (تکست)"/>
        <Button android:id="@+id/btnUpdateKeys" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="بروز‌رسانی کلیدها" android:layout_marginTop="8dp"/>
        <ScrollView android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1">
            <TextView android:id="@+id/tvChat" android:layout_width="match_parent" android:layout_height="wrap_content" android:text=""/>
        </ScrollView>
        <TextView android:id="@+id/tvStatus" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="وضعیت: -"/>
        <TextView android:id="@+id/tvFree" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="استفاده رایگان: 5"/>
        <EditText android:id="@+id/etInput" android:layout_width="match_parent" android:layout_height="wrap_content" android:hint="پیام..."/>
        <Button android:id="@+id/btnMic" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="میکروفون"/>
        <Button android:id="@+id/btnSend" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="ارسال"/>
        <ProgressBar android:id="@+id/progress" android:layout_width="wrap_content" android:layout_height="wrap_content" android:visibility="gone"/>
    </LinearLayout>
""")
write(LAYOUT / "activity_smart.xml", activity_smart_xml)

strings_xml = textwrap.dedent("""\
    <resources>
        <string name="app_name">یار هوشمند</string>
    </resources>
""")
write(VALUES / "strings.xml", strings_xml)

# 9) README
readme = textwrap.dedent("""\
    پروژهٔ سبک‌شده‌ی «یار هوشمند» - راهنمای سریع

    1) اجرا:
       - فایل make_project.py را اجرا کن (python make_project.py) تا پوشه YarHooshmand ساخته شود.
       - سپس Android Studio را باز کن و از File -> Open پوشه YarHooshmand را انتخاب کن.

    2) پیش‌نیازها:
       - اندروید استودیو (پرتابل هم اوکیه)
       - SDK Platform 28+ و Build-tools نصب باشد (Android Studio هنگام sync درخواست می‌کند)
       - اینترنت یا پروکسی برای دانلود وابستگی‌ها در اولین sync نیاز است.

    3) تست سریع:
       - پس از sync از Build -> Build Bundle(s) / APK(s) -> Build APK(s) استفاده کن.
       - یا در CMD داخل پوشه پروژه دستور gradlew.bat assembleDebug را اجرا کن (Windows).

    4) Google Drive keys:
       - در بخش هوشمند، لینک پیش‌فرض فایل تکست Google Drive قرار دارد.
       - فرمت فایل تکست: هر خط یک کلید یا "service:key" مانند:
           openai:sk-...
           openrouter:rk-...
       - اگر دانلود از Drive انجام نشد، می‌توانی کلید را دستی در SharedPreferences ذخیره کنی (تنظیمات داخل کد).

    5) نکات امنیتی:
       - نگهداری کلیدها روی دستگاه ناامن است؛ برای انتشار واقعی از سرور واسط استفاده کن.

    اگر خواستی من می‌تونم:
    - mirrorهای لازم را به build.gradle اضافه کنم (برای کشورهایی که dl.google.com فیلتر است)
    - نمونه gradle-wrapper.jar واقعی و gradle-7.5-bin.zip را راهنمایی کنم که دستی دانلود و قرار دهی
    - پس از تست، بخش IAP را اضافه کنم.
""")
write(ROOT / "README.md", readme)

# 10) build_apk.bat
bat = textwrap.dedent("""\
    @echo off
    chcp 65001 >nul
    echo Building APK (debug)...
    if exist gradlew.bat (
      call gradlew.bat assembleDebug
    ) else (
      echo gradlew.bat not found. Please run 'gradle wrapper' or use Android Studio.
      pause
      exit /b 1
    )
    if %ERRORLEVEL% NEQ 0 (
      echo Build failed.
      pause
      exit /b 1
    )
    echo Build succeeded. Opening output folder...
    explorer "%cd%\\app\\build\\outputs\\apk\\debug"
    pause
""")
write(ROOT / "build_apk.bat", bat)

print("\nDone. Project created at:", ROOT)
print("Next: open YarHooshmand in Android Studio and allow Gradle sync (it will download required tooling).")
